class TrinityBridge:
    pass
