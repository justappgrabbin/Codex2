class TrinityCalculator:
    pass
