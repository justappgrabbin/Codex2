class GateOperatorEngine:
    pass
