def collapse(): pass
