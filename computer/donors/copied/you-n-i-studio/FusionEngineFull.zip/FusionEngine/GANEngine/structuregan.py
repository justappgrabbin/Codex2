class StructureGAN:
    pass
