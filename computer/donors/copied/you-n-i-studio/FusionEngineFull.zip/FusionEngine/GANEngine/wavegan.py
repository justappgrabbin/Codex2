class WaveGAN:
    pass
