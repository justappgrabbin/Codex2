class GANBridge:
    pass
